setwd("C:\\Users\\IT24102180\\Desktop\\IT24102180")

#question1
branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")

#question2
str(branch_data)

#question3
boxplot(branch_data$Sales_X1, main="Box plot of Sales", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(branch_data$Advertising_X2, main="Box plot of Advertising", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(branch_data$Years_X3, main="Box plot of Years", outline=TRUE, outpch=8, horizontal=TRUE)

#question4
summary(branch_data$Advertising_X2)

IQR(branch_data$Advertising_X2)

#question5
get.outliers<-function(z){
  q1<-quantile(z)[2]
  q3<-quantile(z)[4]
  iqr<-q3-q1
  
  ub<-q3+1.5*iqr
  lb<-q1-1.5*iqr
  
  print(paste("Upper Bound=",ub))
  print(paste("Lower Bound=",lb))
  print(paste("Outliers:", paste(sort(z[z<lb | z>ub]), collapse=",")))
}
get.outliers(branch_data$Years_X3)  
